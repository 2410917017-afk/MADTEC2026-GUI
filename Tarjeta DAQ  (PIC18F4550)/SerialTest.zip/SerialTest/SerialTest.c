#include <18f4550.h>
#fuses HS, CPUDIV1, NODEBUG, NOLVP, NOBROWNOUT
#DEVICE ADC=10
#use delay(clock=20M)
#use rs232(stream=COM1, baud=38400, xmit=PIN_C6, rcv=PIN_C7, parity=N, bits=8)
#define MUESTRAS 80
#define CICLOS 5
#define CICLOS_TOTAL 400
#define BOTON PIN_B2

int16 i = 0;
int16 datos[400];
int16 indice = 0;

short estado_ant = False;
short estado = False;
short flag = 0;

#INT_TIMER1
void timer1_isr()
{
   set_timer1(65081);
   
   datos[indice] = read_adc();
   indice++;
   
   if(indice >= CICLOS_TOTAL)
      {
      indice = 0;
      flag = 1;
      }
}

void main()
{  
   set_tris_b(0b11111100);
   output_low(PIN_B0);
   output_low(PIN_B1);

   setup_adc(ADC_CLOCK_DIV_32);
   setup_adc_ports(AN0_ANALOG);
   set_adc_channel(0);
   delay_us(20);


   enable_interrupts(INT_TIMER1);
   enable_interrupts(GLOBAL);
    
 while(true)
 {
   //C�digo para detecci�n de dispato
   output_high(PIN_B1);
   estado = input(BOTON);
   output_low(PIN_B0);
   //Inicio de muestreo
   if(estado == 1 && estado_ant == 0)
       {
       delay_ms(50); // Anti-rebote
       indice = 0;
       setup_timer_1(T1_INTERNAL | T1_DIV_BY_1);
       set_timer1(65081);
       }
       
    if(flag)
       {
       output_high(PIN_B0);
       setup_timer_1(T1_DISABLED);
       flag = 0;
//Bloque 1       
       putc(0xAA);
        for(i=0;i<100;i++)
        {
        
         if(i<99)
          printf("%lu,", datos[i]);
         
         else
          printf("%lu",datos[i]);
        }
        putc(0xBB);
        putc(0xBB);
        putc(0xBB);
        putc(0xBB);
        putc(0xBB);
//Bloque 2        
        putc(0xAA);
        for(i=101;i<200;i++)
        {
        
         if(i<199)
          printf("%lu,", datos[i]);
         
         else
          printf("%lu",datos[i]);
        }
        putc(0xBB);
        putc(0xBB);
        putc(0xBB);
        putc(0xBB);
        putc(0xBB);
//Bloque 3        
        putc(0xAA);
        for(i=201;i<300;i++)
        {
        
         if(i<299)
          printf("%lu,", datos[i]);
         
         else
          printf("%lu",datos[i]);
        }
        putc(0xBB);
        putc(0xBB);
        putc(0xBB);
        putc(0xBB);
        putc(0xBB);
//Bloque 4        
        putc(0xAA);
        for(i=301;i<CICLOS_TOTAL;i++)
        {
        
         if(i<CICLOS_TOTAL-1)
          printf("%lu,", datos[i]);
         
         else
          printf("%lu",datos[i]);
        }
        putc(0xBB);
        putc(0xBB);
        putc(0xBB);
        putc(0xBB);
        putc(0xBB);
     
    }
    estado_ant = estado;
 }
}
