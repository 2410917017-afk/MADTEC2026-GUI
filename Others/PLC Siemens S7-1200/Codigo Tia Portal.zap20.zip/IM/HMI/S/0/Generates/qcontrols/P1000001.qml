﻿import QtQuick 2.7
import "qrc:/"
IGuiPage
{
	id: q16777217
	objId: 16777217
	x: 0
	y: 0
	width: 800
	height: 480
	IGuiButton
	{
		id: q486539303
		objId: 486539303
		x: 1
		y: 1
		width: 159
		height: 47
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 1
		qm_ImageSource: "image://QSmartImageProvider/21#2#4#128#0#0"
		qm_Border.top: 15
		qm_Border.bottom: 15
		qm_Border.right: 5
		qm_Border.left: 5
		qm_FillColor: "#ffe7e3e7"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 1
		qm_Anchors.leftMargin: 1
		qm_Anchors.rightMargin: 1
		qm_Anchors.topMargin: 1
		qm_FocusWidth: 2
		qm_FocusColor: "#ff94b6e7"
	}
	IGuiTextField
	{
		id: q268435466
		objId: 268435466
		x: 281
		y: 2
		width: 238
		height: 62
		qm_BorderCornerRadius: 3
		qm_ImageSource: "image://QSmartImageProvider/32#2#4#128#0#0"
		qm_Border.top: 0
		qm_Border.bottom: 0
		qm_Border.right: 0
		qm_Border.left: 0
		qm_FillColor: "#ffffff00"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiIOField
	{
		id: q33554440
		objId: 33554440
		x: 645
		y: 4
		width: 133
		height: 30
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiIOField
	{
		id: q33554441
		objId: 33554441
		x: 644
		y: 31
		width: 138
		height: 30
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiQmlRectangle
	{
		id: q671088651
		objId: 671088651
		x: 341
		y: 221
		width: 387
		height: 62
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffceffff"
		qm_RectangleWidth: 387
		qm_RectangleHeight: 62
	}
	IGuiContainer
	{
		id: q369098752
		objId: 369098752
		x: 653
		y: 83
		width: 130
		height: 91
		IGuiQmlRectangle
		{
			id: q671088649
			objId: 671088649
			x: 0
			y: 0
			width: 130
			height: 91
			qm_BorderWidth: 1
			qm_TextColor: "#ff181c31"
			qm_FillColor: "#ffdedbde"
			qm_RectangleWidth: 130
			qm_RectangleHeight: 91
		}
		IGuiIOField
		{
			id: q33554439
			objId: 33554439
			x: 0
			y: 30
			width: 130
			height: 32
			qm_Transparent : true 
			qm_TextColor: "#ff31344a"
			qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
			qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 3
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
	}
	IGuiQmlRectangle
	{
		id: q671088650
		objId: 671088650
		x: 341
		y: 84
		width: 306
		height: 127
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffceffff"
		qm_RectangleWidth: 306
		qm_RectangleHeight: 127
	}
	IGuiContainer
	{
		id: q369098753
		objId: 369098753
		x: 353
		y: 84
		width: 280
		height: 27
		IGuiQmlRectangle
		{
			id: q671088652
			objId: 671088652
			x: 0
			y: 0
			width: 280
			height: 27
			qm_BorderWidth: 1
			qm_TextColor: "#ff181c31"
			qm_FillColor: "#ffffcf00"
			qm_RectangleWidth: 280
			qm_RectangleHeight: 27
		}
		IGuiTextField
		{
			id: q268435467
			objId: 268435467
			x: 0
			y: 0
			width: 280
			height: 27
			qm_Transparent : true 
			qm_TextColor: "#ff31344a"
			qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 3
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
	}
	IGuiIOField
	{
		id: q33554442
		objId: 33554442
		x: 515
		y: 129
		width: 96
		height: 57
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 1
		qm_ImageSource: "image://QSmartImageProvider/33#2#4#128#0#0"
		qm_Border.top: 5
		qm_Border.bottom: 5
		qm_Border.right: 5
		qm_Border.left: 5
		qm_FillColor: "#ffc6c3c6"
		qm_FocusWidth: 0
		qm_FocusColor: "#00000000"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 3
		qm_Anchors.leftMargin: 4
		qm_Anchors.rightMargin: 3
		qm_Anchors.topMargin: 3
	}
	IGuiContainer
	{
		id: q369098754
		objId: 369098754
		x: 362
		y: 129
		width: 96
		height: 57
		IGuiGraphicSwitch
		{
			id: q352321536
			objId: 352321536
			x: 0
			y: 0
			width: 96
			height: 57
			qm_RectangleBorder.width:0
			qm_RectangleBorder.color:"#ff000000"
			qm_FillColor: "#ffb5b6b5"
			qm_FocusWidth: 1
			qm_FocusColor: "#ff000000"
			qm_ImageWidth: 96
			qm_ImageHeight: 57
			qm_SourceSizeWidth: 96
			qm_SourceSizeHeight: 57
		}
		IGuiTextField
		{
			id: q268435468
			objId: 268435468
			x: 22
			y: 15
			width: 52
			height: 27
			qm_Transparent : true 
			qm_TextColor: "#ff31344a"
			qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 3
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
	}
	IGuiButton
	{
		id: q486539304
		objId: 486539304
		x: 344
		y: 231
		width: 82
		height: 42
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 2
		qm_ImageSource: "image://QSmartImageProvider/38#2#4#128#0#0"
		qm_Border.top: 15
		qm_Border.bottom: 15
		qm_Border.right: 5
		qm_Border.left: 5
		qm_FillColor: "#ff636573"
		qm_TextColor: "#ffffffff"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
		qm_FocusWidth: 2
		qm_FocusColor: "#ff94b6e7"
	}
	IGuiButton
	{
		id: q486539305
		objId: 486539305
		x: 443
		y: 231
		width: 82
		height: 42
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 2
		qm_ImageSource: "image://QSmartImageProvider/38#2#4#128#0#0"
		qm_Border.top: 15
		qm_Border.bottom: 15
		qm_Border.right: 5
		qm_Border.left: 5
		qm_FillColor: "#ff636573"
		qm_TextColor: "#ffffffff"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
		qm_FocusWidth: 2
		qm_FocusColor: "#ff94b6e7"
	}
	IGuiButton
	{
		id: q486539306
		objId: 486539306
		x: 543
		y: 231
		width: 82
		height: 42
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 2
		qm_ImageSource: "image://QSmartImageProvider/38#2#4#128#0#0"
		qm_Border.top: 15
		qm_Border.bottom: 15
		qm_Border.right: 5
		qm_Border.left: 5
		qm_FillColor: "#ff636573"
		qm_TextColor: "#ffffffff"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
		qm_FocusWidth: 2
		qm_FocusColor: "#ff94b6e7"
	}
	IGuiButton
	{
		id: q486539307
		objId: 486539307
		x: 643
		y: 231
		width: 82
		height: 42
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 2
		qm_ImageSource: "image://QSmartImageProvider/38#2#4#128#0#0"
		qm_Border.top: 15
		qm_Border.bottom: 15
		qm_Border.right: 5
		qm_Border.left: 5
		qm_FillColor: "#ff636573"
		qm_TextColor: "#ffffffff"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
		qm_FocusWidth: 2
		qm_FocusColor: "#ff94b6e7"
	}
	IGuiQmlRectangle
	{
		id: q671088653
		objId: 671088653
		x: 130
		y: 84
		width: 201
		height: 202
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffceffff"
		qm_RectangleWidth: 201
		qm_RectangleHeight: 202
	}
	IGuiContainer
	{
		id: q369098755
		objId: 369098755
		x: 189
		y: 84
		width: 83
		height: 27
		IGuiQmlRectangle
		{
			id: q671088654
			objId: 671088654
			x: 0
			y: 0
			width: 83
			height: 27
			qm_BorderWidth: 1
			qm_TextColor: "#ff181c31"
			qm_FillColor: "#ffffcf00"
			qm_RectangleWidth: 83
			qm_RectangleHeight: 27
		}
		IGuiTextField
		{
			id: q268435469
			objId: 268435469
			x: 0
			y: 0
			width: 80
			height: 27
			qm_Transparent : true 
			qm_TextColor: "#ff31344a"
			qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 3
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
	}
	IGuiTextField
	{
		id: q268435470
		objId: 268435470
		x: 154
		y: 128
		width: 56
		height: 23
		qm_BorderCornerRadius: 10
		qm_ImageSource: "image://QSmartImageProvider/39#2#4#128#0#0"
		qm_Border.top: 0
		qm_Border.bottom: 0
		qm_Border.right: 0
		qm_Border.left: 0
		qm_FillColor: "#ff9ccf00"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435471
		objId: 268435471
		x: 139
		y: 164
		width: 71
		height: 23
		qm_BorderCornerRadius: 10
		qm_ImageSource: "image://QSmartImageProvider/39#2#4#128#0#0"
		qm_Border.top: 0
		qm_Border.bottom: 0
		qm_Border.right: 0
		qm_Border.left: 0
		qm_FillColor: "#ff9ccf00"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435472
		objId: 268435472
		x: 139
		y: 201
		width: 71
		height: 23
		qm_BorderCornerRadius: 10
		qm_ImageSource: "image://QSmartImageProvider/39#2#4#128#0#0"
		qm_Border.top: 0
		qm_Border.bottom: 0
		qm_Border.right: 0
		qm_Border.left: 0
		qm_FillColor: "#ff9ccf00"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435473
		objId: 268435473
		x: 149
		y: 238
		width: 61
		height: 23
		qm_BorderCornerRadius: 10
		qm_ImageSource: "image://QSmartImageProvider/39#2#4#128#0#0"
		qm_Border.top: 0
		qm_Border.bottom: 0
		qm_Border.right: 0
		qm_Border.left: 0
		qm_FillColor: "#ff9ccf00"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544321
		objId: 335544321
		x: 218
		y: 126
		width: 91
		height: 28
		qm_RectangleBorder.width:0
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffb5b6b5"
		qm_ImageWidth: 91
		qm_ImageHeight: 28
		qm_SourceSizeWidth: 91
		qm_SourceSizeHeight: 28
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544322
		objId: 335544322
		x: 218
		y: 162
		width: 91
		height: 28
		qm_RectangleBorder.width:0
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffb5b6b5"
		qm_ImageWidth: 91
		qm_ImageHeight: 28
		qm_SourceSizeWidth: 91
		qm_SourceSizeHeight: 28
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544323
		objId: 335544323
		x: 218
		y: 199
		width: 91
		height: 28
		qm_RectangleBorder.width:0
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffb5b6b5"
		qm_ImageWidth: 91
		qm_ImageHeight: 28
		qm_SourceSizeWidth: 91
		qm_SourceSizeHeight: 28
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544324
		objId: 335544324
		x: 218
		y: 236
		width: 91
		height: 28
		qm_RectangleBorder.width:0
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffb5b6b5"
		qm_ImageWidth: 91
		qm_ImageHeight: 28
		qm_SourceSizeWidth: 91
		qm_SourceSizeHeight: 28
	}
}
