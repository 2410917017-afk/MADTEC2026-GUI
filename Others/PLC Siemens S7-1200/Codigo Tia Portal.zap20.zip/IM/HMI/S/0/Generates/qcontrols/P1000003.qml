﻿import QtQuick 2.7
import "qrc:/"
IGuiPage
{
	id: q16777219
	objId: 16777219
	x: 0
	y: 0
	width: 800
	height: 480
	IGuiButton
	{
		id: q486539310
		objId: 486539310
		x: 1
		y: 1
		width: 159
		height: 47
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 1
		qm_ImageSource: "image://QSmartImageProvider/21#2#4#128#0#0"
		qm_Border.top: 15
		qm_Border.bottom: 15
		qm_Border.right: 5
		qm_Border.left: 5
		qm_FillColor: "#ffe7e3e7"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 1
		qm_Anchors.leftMargin: 1
		qm_Anchors.rightMargin: 1
		qm_Anchors.topMargin: 1
		qm_FocusWidth: 2
		qm_FocusColor: "#ff94b6e7"
	}
	IGuiTextField
	{
		id: q268435501
		objId: 268435501
		x: 200
		y: 2
		width: 400
		height: 62
		qm_BorderCornerRadius: 3
		qm_ImageSource: "image://QSmartImageProvider/32#2#4#128#0#0"
		qm_Border.top: 0
		qm_Border.bottom: 0
		qm_Border.right: 0
		qm_Border.left: 0
		qm_FillColor: "#ffffff00"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiQmlRectangle
	{
		id: q671088667
		objId: 671088667
		x: 176
		y: 94
		width: 448
		height: 106
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffceffff"
		qm_RectangleWidth: 448
		qm_RectangleHeight: 106
	}
	IGuiTextField
	{
		id: q268435503
		objId: 268435503
		x: 279
		y: 94
		width: 243
		height: 27
		qm_BorderCornerRadius: 10
		qm_ImageSource: "image://QSmartImageProvider/39#2#4#128#0#0"
		qm_Border.top: 0
		qm_Border.bottom: 0
		qm_Border.right: 0
		qm_Border.left: 0
		qm_FillColor: "#ffffcf00"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiIOField
	{
		id: q33554443
		objId: 33554443
		x: 205
		y: 159
		width: 150
		height: 38
		qm_BorderCornerRadius: 6
		qm_BorderWidth: 4
		qm_ImageSource: "image://QSmartImageProvider/48#2#4#128#0#0"
		qm_Border.top: 8
		qm_Border.bottom: 8
		qm_Border.right: 8
		qm_Border.left: 8
		qm_FillColor: "#ffffffff"
		qm_FocusWidth: 0
		qm_FocusColor: "#00000000"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 6
		qm_Anchors.leftMargin: 7
		qm_Anchors.rightMargin: 6
		qm_Anchors.topMargin: 6
	}
	IGuiTextField
	{
		id: q268435502
		objId: 268435502
		x: 190
		y: 128
		width: 179
		height: 23
		qm_BorderCornerRadius: 10
		qm_ImageSource: "image://QSmartImageProvider/39#2#4#128#0#0"
		qm_Border.top: 0
		qm_Border.bottom: 0
		qm_Border.right: 0
		qm_Border.left: 0
		qm_FillColor: "#ff9ccf00"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435504
		objId: 268435504
		x: 395
		y: 127
		width: 215
		height: 23
		qm_BorderCornerRadius: 10
		qm_ImageSource: "image://QSmartImageProvider/39#2#4#128#0#0"
		qm_Border.top: 0
		qm_Border.bottom: 0
		qm_Border.right: 0
		qm_Border.left: 0
		qm_FillColor: "#ff9ccf00"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiIOField
	{
		id: q33554444
		objId: 33554444
		x: 428
		y: 158
		width: 150
		height: 38
		qm_BorderCornerRadius: 6
		qm_BorderWidth: 4
		qm_ImageSource: "image://QSmartImageProvider/49#2#4#128#0#0"
		qm_Border.top: 8
		qm_Border.bottom: 8
		qm_Border.right: 8
		qm_Border.left: 8
		qm_FillColor: "#ffffffff"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 6
		qm_Anchors.leftMargin: 7
		qm_Anchors.rightMargin: 6
		qm_Anchors.topMargin: 6
	}
}
