﻿import QtQuick 2.7
import "qrc:/"
IGuiPage
{
	id: q16777218
	objId: 16777218
	x: 0
	y: 0
	width: 800
	height: 480
	IGuiButton
	{
		id: q486539308
		objId: 486539308
		x: 1
		y: 1
		width: 159
		height: 47
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 1
		qm_ImageSource: "image://QSmartImageProvider/21#2#4#128#0#0"
		qm_Border.top: 15
		qm_Border.bottom: 15
		qm_Border.right: 5
		qm_Border.left: 5
		qm_FillColor: "#ffe7e3e7"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 1
		qm_Anchors.leftMargin: 1
		qm_Anchors.rightMargin: 1
		qm_Anchors.topMargin: 1
		qm_FocusWidth: 2
		qm_FocusColor: "#ff94b6e7"
	}
	IGuiTextField
	{
		id: q268435474
		objId: 268435474
		x: 365
		y: 1
		width: 16
		height: 23
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435475
		objId: 268435475
		x: 193
		y: 2
		width: 415
		height: 62
		qm_BorderCornerRadius: 3
		qm_ImageSource: "image://QSmartImageProvider/32#2#4#128#0#0"
		qm_Border.top: 0
		qm_Border.bottom: 0
		qm_Border.right: 0
		qm_Border.left: 0
		qm_FillColor: "#ffffff00"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiQmlRectangle
	{
		id: q671088655
		objId: 671088655
		x: 670
		y: 77
		width: 122
		height: 340
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffceffff"
		qm_RectangleWidth: 122
		qm_RectangleHeight: 340
	}
	IGuiGraphicButton
	{
		id: q486539309
		objId: 486539309
		x: 739
		y: 122
		width: 50
		height: 60
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 2
		qm_RectangleBorder.width:2
		qm_RectangleBorder.color:"#ff424952"
		qm_FillColor: "#ff840000"
		qm_FocusWidth: 2
		qm_FocusColor: "#ff94b6e7"
		qm_ImagePossitionX: 2
		qm_ImagePossitionY: 2
		qm_ImageWidth: 46
		qm_ImageHeight: 56
		qm_SourceSizeWidth: 46
		qm_SourceSizeHeight: 56
	}
	IGuiTextField
	{
		id: q268435500
		objId: 268435500
		x: 677
		y: 77
		width: 108
		height: 34
		qm_BorderCornerRadius: 3
		qm_ImageSource: "image://QSmartImageProvider/32#2#4#128#0#0"
		qm_Border.top: 0
		qm_Border.bottom: 0
		qm_Border.right: 0
		qm_Border.left: 0
		qm_FillColor: "#ffffcf00"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435477
		objId: 268435477
		x: 673
		y: 136
		width: 62
		height: 34
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiQmlRectangle
	{
		id: q671088656
		objId: 671088656
		x: 8
		y: 77
		width: 151
		height: 340
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffceffff"
		qm_RectangleWidth: 151
		qm_RectangleHeight: 340
	}
	IGuiTextField
	{
		id: q268435476
		objId: 268435476
		x: 13
		y: 77
		width: 141
		height: 34
		qm_BorderCornerRadius: 3
		qm_ImageSource: "image://QSmartImageProvider/32#2#4#128#0#0"
		qm_Border.top: 0
		qm_Border.bottom: 0
		qm_Border.right: 0
		qm_Border.left: 0
		qm_FillColor: "#ffffcf00"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435478
		objId: 268435478
		x: 22
		y: 122
		width: 55
		height: 34
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435479
		objId: 268435479
		x: 22
		y: 158
		width: 55
		height: 34
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435480
		objId: 268435480
		x: 22
		y: 194
		width: 55
		height: 34
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435481
		objId: 268435481
		x: 22
		y: 230
		width: 55
		height: 34
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435482
		objId: 268435482
		x: 22
		y: 266
		width: 55
		height: 34
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435483
		objId: 268435483
		x: 22
		y: 302
		width: 55
		height: 34
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435484
		objId: 268435484
		x: 22
		y: 338
		width: 55
		height: 34
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435485
		objId: 268435485
		x: 22
		y: 374
		width: 55
		height: 34
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiQmlRectangle
	{
		id: q671088657
		objId: 671088657
		x: 110
		y: 163
		width: 30
		height: 24
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 30
		qm_RectangleHeight: 24
	}
	IGuiQmlRectangle
	{
		id: q671088659
		objId: 671088659
		x: 109
		y: 127
		width: 31
		height: 24
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 31
		qm_RectangleHeight: 24
	}
	IGuiQmlRectangle
	{
		id: q671088660
		objId: 671088660
		x: 109
		y: 199
		width: 31
		height: 24
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 31
		qm_RectangleHeight: 24
	}
	IGuiQmlRectangle
	{
		id: q671088661
		objId: 671088661
		x: 109
		y: 235
		width: 31
		height: 24
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 31
		qm_RectangleHeight: 24
	}
	IGuiQmlRectangle
	{
		id: q671088662
		objId: 671088662
		x: 109
		y: 271
		width: 31
		height: 24
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 31
		qm_RectangleHeight: 24
	}
	IGuiQmlRectangle
	{
		id: q671088663
		objId: 671088663
		x: 109
		y: 307
		width: 31
		height: 24
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 31
		qm_RectangleHeight: 24
	}
	IGuiQmlRectangle
	{
		id: q671088664
		objId: 671088664
		x: 109
		y: 343
		width: 31
		height: 24
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 31
		qm_RectangleHeight: 24
	}
	IGuiQmlRectangle
	{
		id: q671088665
		objId: 671088665
		x: 109
		y: 379
		width: 31
		height: 24
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 31
		qm_RectangleHeight: 24
	}
	IGuiQmlRectangle
	{
		id: q671088666
		objId: 671088666
		x: 169
		y: 77
		width: 240
		height: 340
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffceffff"
		qm_RectangleWidth: 240
		qm_RectangleHeight: 340
	}
	IGuiTextField
	{
		id: q268435493
		objId: 268435493
		x: 172
		y: 136
		width: 62
		height: 34
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435494
		objId: 268435494
		x: 172
		y: 202
		width: 62
		height: 34
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435495
		objId: 268435495
		x: 172
		y: 268
		width: 62
		height: 34
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435496
		objId: 268435496
		x: 172
		y: 335
		width: 62
		height: 34
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544329
		objId: 335544329
		x: 364
		y: 133
		width: 40
		height: 40
		qm_RectangleBorder.width:0
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffb5b6b5"
		qm_ImageWidth: 40
		qm_ImageHeight: 40
		qm_SourceSizeWidth: 40
		qm_SourceSizeHeight: 40
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544330
		objId: 335544330
		x: 363
		y: 199
		width: 40
		height: 40
		qm_RectangleBorder.width:0
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffb5b6b5"
		qm_ImageWidth: 40
		qm_ImageHeight: 40
		qm_SourceSizeWidth: 40
		qm_SourceSizeHeight: 40
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544331
		objId: 335544331
		x: 365
		y: 332
		width: 40
		height: 40
		qm_RectangleBorder.width:0
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffb5b6b5"
		qm_ImageWidth: 40
		qm_ImageHeight: 40
		qm_SourceSizeWidth: 40
		qm_SourceSizeHeight: 40
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544332
		objId: 335544332
		x: 365
		y: 265
		width: 40
		height: 40
		qm_RectangleBorder.width:0
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffb5b6b5"
		qm_ImageWidth: 40
		qm_ImageHeight: 40
		qm_SourceSizeWidth: 40
		qm_SourceSizeHeight: 40
	}
	IGuiGraphicSwitch
	{
		id: q352321546
		objId: 352321546
		x: 303
		y: 123
		width: 50
		height: 60
		qm_RectangleBorder.width:0
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffb5b6b5"
		qm_FocusWidth: 1
		qm_FocusColor: "#ff000000"
		qm_ImageWidth: 50
		qm_ImageHeight: 60
		qm_SourceSizeWidth: 50
		qm_SourceSizeHeight: 60
	}
	IGuiGraphicSwitch
	{
		id: q352321547
		objId: 352321547
		x: 238
		y: 189
		width: 50
		height: 60
		qm_RectangleBorder.width:0
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffb5b6b5"
		qm_FocusWidth: 1
		qm_FocusColor: "#ff000000"
		qm_ImageWidth: 50
		qm_ImageHeight: 60
		qm_SourceSizeWidth: 50
		qm_SourceSizeHeight: 60
	}
	IGuiGraphicSwitch
	{
		id: q352321548
		objId: 352321548
		x: 303
		y: 255
		width: 50
		height: 60
		qm_RectangleBorder.width:0
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffb5b6b5"
		qm_FocusWidth: 1
		qm_FocusColor: "#ff000000"
		qm_ImageWidth: 50
		qm_ImageHeight: 60
		qm_SourceSizeWidth: 50
		qm_SourceSizeHeight: 60
	}
	IGuiGraphicSwitch
	{
		id: q352321549
		objId: 352321549
		x: 303
		y: 322
		width: 50
		height: 60
		qm_RectangleBorder.width:0
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffb5b6b5"
		qm_FocusWidth: 1
		qm_FocusColor: "#ff000000"
		qm_ImageWidth: 50
		qm_ImageHeight: 60
		qm_SourceSizeWidth: 50
		qm_SourceSizeHeight: 60
	}
	IGuiGraphicSwitch
	{
		id: q352321550
		objId: 352321550
		x: 238
		y: 255
		width: 50
		height: 60
		qm_RectangleBorder.width:0
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffb5b6b5"
		qm_FocusWidth: 1
		qm_FocusColor: "#ff000000"
		qm_ImageWidth: 50
		qm_ImageHeight: 60
		qm_SourceSizeWidth: 50
		qm_SourceSizeHeight: 60
	}
	IGuiGraphicSwitch
	{
		id: q352321551
		objId: 352321551
		x: 238
		y: 123
		width: 50
		height: 60
		qm_RectangleBorder.width:0
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffb5b6b5"
		qm_FocusWidth: 1
		qm_FocusColor: "#ff000000"
		qm_ImageWidth: 50
		qm_ImageHeight: 60
		qm_SourceSizeWidth: 50
		qm_SourceSizeHeight: 60
	}
	IGuiGraphicSwitch
	{
		id: q352321552
		objId: 352321552
		x: 238
		y: 322
		width: 50
		height: 60
		qm_RectangleBorder.width:0
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffb5b6b5"
		qm_FocusWidth: 1
		qm_FocusColor: "#ff000000"
		qm_ImageWidth: 50
		qm_ImageHeight: 60
		qm_SourceSizeWidth: 50
		qm_SourceSizeHeight: 60
	}
	IGuiTextField
	{
		id: q268435497
		objId: 268435497
		x: 174
		y: 390
		width: 115
		height: 27
		qm_BorderCornerRadius: 3
		qm_ImageSource: "image://QSmartImageProvider/32#2#4#128#0#0"
		qm_Border.top: 0
		qm_Border.bottom: 0
		qm_Border.right: 0
		qm_Border.left: 0
		qm_FillColor: "#ff9ccf00"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignRight
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 3
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435498
		objId: 268435498
		x: 305
		y: 390
		width: 46
		height: 27
		qm_BorderCornerRadius: 3
		qm_ImageSource: "image://QSmartImageProvider/32#2#4#128#0#0"
		qm_Border.top: 0
		qm_Border.bottom: 0
		qm_Border.right: 0
		qm_Border.left: 0
		qm_FillColor: "#ff9ccf00"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignRight
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 3
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435499
		objId: 268435499
		x: 187
		y: 77
		width: 204
		height: 34
		qm_BorderCornerRadius: 3
		qm_ImageSource: "image://QSmartImageProvider/32#2#4#128#0#0"
		qm_Border.top: 0
		qm_Border.bottom: 0
		qm_Border.right: 0
		qm_Border.left: 0
		qm_FillColor: "#ffffcf00"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiGraphicSwitch
	{
		id: q352321545
		objId: 352321545
		x: 303
		y: 189
		width: 50
		height: 60
		qm_RectangleBorder.width:0
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffb5b6b5"
		qm_FocusWidth: 1
		qm_FocusColor: "#ff000000"
		qm_ImageWidth: 50
		qm_ImageHeight: 60
		qm_SourceSizeWidth: 50
		qm_SourceSizeHeight: 60
	}
	IGuiQmlRectangle
	{
		id: q671088658
		objId: 671088658
		x: 421
		y: 76
		width: 238
		height: 340
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffceffff"
		qm_RectangleWidth: 238
		qm_RectangleHeight: 340
	}
	IGuiTextField
	{
		id: q268435486
		objId: 268435486
		x: 424
		y: 135
		width: 62
		height: 34
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435487
		objId: 268435487
		x: 424
		y: 201
		width: 62
		height: 34
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435488
		objId: 268435488
		x: 424
		y: 267
		width: 62
		height: 34
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435489
		objId: 268435489
		x: 424
		y: 334
		width: 62
		height: 34
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544325
		objId: 335544325
		x: 614
		y: 132
		width: 40
		height: 40
		qm_RectangleBorder.width:0
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffb5b6b5"
		qm_ImageWidth: 40
		qm_ImageHeight: 40
		qm_SourceSizeWidth: 40
		qm_SourceSizeHeight: 40
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544326
		objId: 335544326
		x: 614
		y: 198
		width: 40
		height: 40
		qm_RectangleBorder.width:0
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffb5b6b5"
		qm_ImageWidth: 40
		qm_ImageHeight: 40
		qm_SourceSizeWidth: 40
		qm_SourceSizeHeight: 40
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544327
		objId: 335544327
		x: 614
		y: 331
		width: 40
		height: 40
		qm_RectangleBorder.width:0
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffb5b6b5"
		qm_ImageWidth: 40
		qm_ImageHeight: 40
		qm_SourceSizeWidth: 40
		qm_SourceSizeHeight: 40
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544328
		objId: 335544328
		x: 614
		y: 264
		width: 40
		height: 40
		qm_RectangleBorder.width:0
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffb5b6b5"
		qm_ImageWidth: 40
		qm_ImageHeight: 40
		qm_SourceSizeWidth: 40
		qm_SourceSizeHeight: 40
	}
	IGuiGraphicSwitch
	{
		id: q352321537
		objId: 352321537
		x: 490
		y: 122
		width: 50
		height: 60
		qm_RectangleBorder.width:0
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffb5b6b5"
		qm_FocusWidth: 1
		qm_FocusColor: "#ff000000"
		qm_ImageWidth: 50
		qm_ImageHeight: 60
		qm_SourceSizeWidth: 50
		qm_SourceSizeHeight: 60
	}
	IGuiGraphicSwitch
	{
		id: q352321538
		objId: 352321538
		x: 552
		y: 188
		width: 50
		height: 60
		qm_RectangleBorder.width:0
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffb5b6b5"
		qm_FocusWidth: 1
		qm_FocusColor: "#ff000000"
		qm_ImageWidth: 50
		qm_ImageHeight: 60
		qm_SourceSizeWidth: 50
		qm_SourceSizeHeight: 60
	}
	IGuiGraphicSwitch
	{
		id: q352321539
		objId: 352321539
		x: 553
		y: 122
		width: 50
		height: 60
		qm_RectangleBorder.width:0
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffb5b6b5"
		qm_FocusWidth: 1
		qm_FocusColor: "#ff000000"
		qm_ImageWidth: 50
		qm_ImageHeight: 60
		qm_SourceSizeWidth: 50
		qm_SourceSizeHeight: 60
	}
	IGuiGraphicSwitch
	{
		id: q352321540
		objId: 352321540
		x: 491
		y: 188
		width: 50
		height: 60
		qm_RectangleBorder.width:0
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffb5b6b5"
		qm_FocusWidth: 1
		qm_FocusColor: "#ff000000"
		qm_ImageWidth: 50
		qm_ImageHeight: 60
		qm_SourceSizeWidth: 50
		qm_SourceSizeHeight: 60
	}
	IGuiGraphicSwitch
	{
		id: q352321541
		objId: 352321541
		x: 553
		y: 254
		width: 50
		height: 60
		qm_RectangleBorder.width:0
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffb5b6b5"
		qm_FocusWidth: 1
		qm_FocusColor: "#ff000000"
		qm_ImageWidth: 50
		qm_ImageHeight: 60
		qm_SourceSizeWidth: 50
		qm_SourceSizeHeight: 60
	}
	IGuiGraphicSwitch
	{
		id: q352321542
		objId: 352321542
		x: 553
		y: 321
		width: 50
		height: 60
		qm_RectangleBorder.width:0
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffb5b6b5"
		qm_FocusWidth: 1
		qm_FocusColor: "#ff000000"
		qm_ImageWidth: 50
		qm_ImageHeight: 60
		qm_SourceSizeWidth: 50
		qm_SourceSizeHeight: 60
	}
	IGuiGraphicSwitch
	{
		id: q352321543
		objId: 352321543
		x: 491
		y: 254
		width: 50
		height: 60
		qm_RectangleBorder.width:0
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffb5b6b5"
		qm_FocusWidth: 1
		qm_FocusColor: "#ff000000"
		qm_ImageWidth: 50
		qm_ImageHeight: 60
		qm_SourceSizeWidth: 50
		qm_SourceSizeHeight: 60
	}
	IGuiGraphicSwitch
	{
		id: q352321544
		objId: 352321544
		x: 493
		y: 321
		width: 50
		height: 60
		qm_RectangleBorder.width:0
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffb5b6b5"
		qm_FocusWidth: 1
		qm_FocusColor: "#ff000000"
		qm_ImageWidth: 50
		qm_ImageHeight: 60
		qm_SourceSizeWidth: 50
		qm_SourceSizeHeight: 60
	}
	IGuiTextField
	{
		id: q268435490
		objId: 268435490
		x: 430
		y: 389
		width: 115
		height: 27
		qm_BorderCornerRadius: 3
		qm_ImageSource: "image://QSmartImageProvider/32#2#4#128#0#0"
		qm_Border.top: 0
		qm_Border.bottom: 0
		qm_Border.right: 0
		qm_Border.left: 0
		qm_FillColor: "#ff9ccf00"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignRight
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 3
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435491
		objId: 268435491
		x: 566
		y: 389
		width: 46
		height: 27
		qm_BorderCornerRadius: 3
		qm_ImageSource: "image://QSmartImageProvider/32#2#4#128#0#0"
		qm_Border.top: 0
		qm_Border.bottom: 0
		qm_Border.right: 0
		qm_Border.left: 0
		qm_FillColor: "#ff9ccf00"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignRight
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 3
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435492
		objId: 268435492
		x: 438
		y: 76
		width: 204
		height: 34
		qm_BorderCornerRadius: 3
		qm_ImageSource: "image://QSmartImageProvider/32#2#4#128#0#0"
		qm_Border.top: 0
		qm_Border.bottom: 0
		qm_Border.right: 0
		qm_Border.left: 0
		qm_FillColor: "#ffffcf00"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
}
